# H4CK3R RIYAD HOSSAIN HOSTING Site

This is a Vercel-ready React + Next.js based hosting frontend for uploading files, generating QR codes, and using Firebase Auth.

## Features
- Firebase Auth (email/password)
- Upload files and generate QR code
- Admin-only access control

## Getting Started

1. Clone this repo
2. Set up Firebase config inside `/pages/login.tsx` and `/pages/admin.tsx`
3. Run locally:

```bash
npm install
npm run dev
```

4. Deploy to Vercel!
